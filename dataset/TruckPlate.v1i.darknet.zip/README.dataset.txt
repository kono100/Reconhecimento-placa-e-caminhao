# TruckPlate > 2023-11-27 7:35pm
https://universe.roboflow.com/faculdade-reges-jdihd/truckplate

Provided by a Roboflow user
License: CC BY 4.0

